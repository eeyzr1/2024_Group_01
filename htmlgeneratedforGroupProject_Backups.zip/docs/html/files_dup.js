var files_dup =
[
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "mainwindow.cpp", "mainwindow_8cpp.html", null ],
    [ "mainwindow.h", "mainwindow_8h.html", "mainwindow_8h" ],
    [ "ModelPart.cpp", "_model_part_8cpp.html", null ],
    [ "ModelPart.h", "_model_part_8h.html", "_model_part_8h" ],
    [ "ModelPartList.h", "_model_part_list_8h.html", "_model_part_list_8h" ],
    [ "optiondialog.cpp", "optiondialog_8cpp.html", null ],
    [ "optiondialog.h", "optiondialog_8h.html", "optiondialog_8h" ]
];