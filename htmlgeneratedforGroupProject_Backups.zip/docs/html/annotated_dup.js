var annotated_dup =
[
    [ "MainWindow", "class_main_window.html", "class_main_window" ],
    [ "ModelPart", "class_model_part.html", "class_model_part" ],
    [ "ModelPartList", "class_model_part_list.html", "class_model_part_list" ],
    [ "OptionDialog", "class_option_dialog.html", "class_option_dialog" ]
];