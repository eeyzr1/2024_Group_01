var hierarchy =
[
    [ "ModelPart", "class_model_part.html", null ],
    [ "QAbstractItemModel", null, [
      [ "ModelPartList", "class_model_part_list.html", null ]
    ] ],
    [ "QDialog", null, [
      [ "OptionDialog", "class_option_dialog.html", null ]
    ] ],
    [ "QMainWindow", null, [
      [ "MainWindow", "class_main_window.html", null ]
    ] ]
];