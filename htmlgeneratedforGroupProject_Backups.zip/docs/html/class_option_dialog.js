var class_option_dialog =
[
    [ "OptionDialog", "class_option_dialog.html#a4540736a5c6e4468dad5165c7aefc8bc", null ],
    [ "~OptionDialog", "class_option_dialog.html#a640a1faddda44f2567cf386de0085ec7", null ],
    [ "setDialog", "class_option_dialog.html#abb3bd747bcba115263264185bddf3b07", null ],
    [ "setModelPart", "class_option_dialog.html#af64ae061949dd999340a6e0ea4782266", null ]
];