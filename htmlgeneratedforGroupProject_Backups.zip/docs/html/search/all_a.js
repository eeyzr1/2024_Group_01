var searchData=
[
  ['parent_0',['parent',['../class_model_part_list.html#a2aeb9586030b325193894ddfe99e629c',1,'ModelPartList']]],
  ['parentitem_1',['parentItem',['../class_model_part.html#a9be3859d2a298e88d850a2480b7639f7',1,'ModelPart']]]
];
