#include "mainwindow.h"
#include "./ui_mainwindow.h" //created by UIC of qt from .ui files
#include "ModelPart.h"
#include "ModelPartList.h"
#include <QFileDialog>//for adding dialog
#include <QtConcurrent>//for concurrent process
#include <QProgressBar>//for showing progress of loading stl model using concurrent

#include <QVTKOpenGLNativeWidget.h>
#include <vtkCylinderSource.h>
#include <vtkPolyDataMapper.h>
#include <vtkActor.h>
#include <vtkRenderer.h>
#include <vtkRenderWindow.h>
#include <vtkProperty.h>
#include <vtkRendererCollection.h>



MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);//initialize

    // Create / allocate the Model List
    this->partList = new ModelPartList("Parts List");

    // Link it to the treeview in the GUI
    ui->treeView->setModel(this->partList);

    // Manually create a model tree (quick example for starting point)
    ModelPart* rootItem = this->partList->getRootItem();

    // Add 3 top level items::wait to be modified later for items
    for (int i = 0; i < 3; i++) {
        // Create strings for both data columns
        QString name = QString("Top Level %1").arg(i);
        QString visible("true");  // ✅ 修正：原为 Qstring v i s i b l e

        // Create child item
        ModelPart* childItem = new ModelPart({name, visible});

        // Append to tree top-level
        rootItem->appendChild(childItem);

        // Add 5 sub-items
        for (int j = 0; j < 5; j++) {
            QString name = QString("Item %1, %2").arg(i).arg(j);
            QString visible("true");  // ✅ 同上

            ModelPart* childChildItem = new ModelPart({name, visible});
            childItem->appendChild(childChildItem);
        }
    }


    /**connect(ui->save,&QPushButton::clicked,this,&MainWindow::saveClicked);//connecting signal with slots
    connect(ui->open,&QPushButton::clicked,this,&MainWindow::openClicked);//connecting signal with slots
    */
    /*connect(ui->shrinkFilter,&QCheckBox::stateChanged,this,&MainWindow::shrink_FilterClicked);//connecting signal with slots
    connect(ui->clipFilter,&QCheckBox::stateChanged,this,&MainWindow::clip_FilterClicked);//connecting signal with slots note avoid deprecated*/
    connect(ui->shrinkFilter, &QCheckBox::checkStateChanged, this, &MainWindow::shrink_FilterClicked);
    connect(ui->clipFilter, &QCheckBox::checkStateChanged, this, &MainWindow::clip_FilterClicked);

    connect(this, &MainWindow::statusUpdateMessage,ui->statusbar, &QStatusBar::showMessage);//connecting signals with status bar
    connect(ui->treeView, &QTreeView::clicked,this, &MainWindow::handleTreeClicked);//connecting treeview items

    //connect(ui->actionOpen_File, &QAction::triggered,this, &MainWindow::on_actionOpen_File_triggered);//Openfile action, note:linked directly by ui viaMOC槽函数在此处被重复调用，引掉以避免ui及cpp中的重复调用，窗口现在仅弹出一次，成功
    connect(ui->actionSave_File, &QAction::triggered,this, &MainWindow::on_actionSave_File_triggered);//Savefile action

    vtkNew<vtkCylinderSource> cylinder;
    cylinder->SetResolution(16);

    vtkNew<vtkPolyDataMapper> mapper;
    mapper->SetInputConnection(cylinder->GetOutputPort());

    vtkNew<vtkActor> actor;
    actor->SetMapper(mapper);

    vtkNew<vtkRenderer> renderer;
    renderer->AddActor(actor);
    renderer->SetBackground(0.1, 0.2, 0.4);

    ui->VTKOpenGLNativeWidget->renderWindow()->AddRenderer(renderer);    //note:new version vtk changed the coding
    /** ✅ 关键：使用正确名称的 VTK widgetui->VTKOpenGLNativeWidget->GetRenderWindow()->AddRenderer(renderer);*/



}

MainWindow::~MainWindow()
{
    delete ui;//release memory
}
/**void MainWindow::saveClicked(){
    //qDebug()<<"Button Clicked";
    emit statusUpdateMessage("Saved!", 3000);  //save file::wait to be add to the file list later
}

void MainWindow::openClicked(){
    emit statusUpdateMessage("Opened!", 3000);  //open file::wait to be add to the file list later
    //wait to be added loop for adding all the files
};//open
*/
void MainWindow::shrink_FilterClicked(int state)
{
    if (state == Qt::Checked)
        emit statusUpdateMessage("Shrink Filter: ON", 3000);
    else
        emit statusUpdateMessage("Shrink Filter: OFF", 3000);
}
//checkbox shrink

void MainWindow::clip_FilterClicked(int state)
{
    if (state == Qt::Checked)
        emit statusUpdateMessage("Clip Filter: ON", 3000);
    else
        emit statusUpdateMessage("Clip Filter: OFF", 3000);
}
//checkbox clip
/*
void MainWindow::handleTreeClicked(const QModelIndex &index)
{
    if (!index.isValid()) return;

    // 获取点击的 ModelPart
    ModelPart* part = static_cast<ModelPart*>(index.internalPointer());
    if (!part) return;

    QString name = part->data(0).toString();  // 第0列是名称
    QString visible = part->data(1).toString();  // 第1列是可见性

    // 显示在状态栏
    emit statusUpdateMessage("Selected: " + name + " (Visible: " + visible + ")", 3000);

    // 此处可加入其他操作，例如高亮、渲染等
}*/
void MainWindow::handleTreeClicked(const QModelIndex &index)
{
    if (!index.isValid()) return;

    ModelPart* part = static_cast<ModelPart*>(index.internalPointer());
    if (!part) return;

    emit statusUpdateMessage("Selected: " + part->data(0).toString(), 3000);

    // 重置所有 actor 为默认颜色
    for (int i = 0; i < partList->rowCount(QModelIndex()); ++i) {
        ModelPart* child = static_cast<ModelPart*>(partList->index(i, 0, QModelIndex()).internalPointer());

        if (child && child->getActor()) {
            child->getActor()->GetProperty()->SetColor(1.0, 1.0, 1.0); // 白
        }
    }

    // 设置当前选中 actor 为高亮颜色
    if (part->getActor()) {
        part->getActor()->GetProperty()->SetColor(1.0, 0.0, 0.0); // 红
    }

    ui->VTKOpenGLNativeWidget->renderWindow()->Render(); // 更新
}


// Slot function added to MainWindow.cpp for save and open
/**void MainWindow::on_actionOpen_File_triggered() {

    // Add this line of code so you can see if the action is working
    emit statusUpdateMessage(QString("Open File action triggered"), 0);
}*/
//second version for open stl and txt file
/**void MainWindow::on_actionOpen_File_triggered()
{
    QString fileName = QFileDialog::getOpenFileName(
        this,
        tr("Open File"),
        "",
        tr("STL Files (*.stl);;All Files (*)")
        );

    if (!fileName.isEmpty()) {
        emit statusUpdateMessage("file selected: " + fileName, 0);
    } else {
        emit statusUpdateMessage("no file yet been chosen", 0);
    }
}*/
/**void MainWindow::on_actionOpen_File_triggered()
{
    QString fileName = QFileDialog::getOpenFileName(
        this,
        tr("Open File"),
        "",
        tr("All Files (*)")
        );

    if (fileName.isEmpty()) {
        emit statusUpdateMessage("No file selected.", 0);
        return;
    }

    QFileInfo selectedFile(fileName);
    QDir directory = selectedFile.absoluteDir();
    QStringList fileList = directory.entryList(QDir::Files | QDir::NoDotAndDotDot);

    // 清空旧模型（如需要，可扩展为多模型共存）
    delete partList;
    partList = new ModelPartList("Parts List");
    ui->treeView->setModel(partList);

    QModelIndex rootIndex = QModelIndex();
    for (const QString& file : fileList) {
        QList<QVariant> columns = { file, "true" };
        partList->appendChild(rootIndex, columns);
    }

    emit statusUpdateMessage("Loaded directory: " + directory.absolutePath(), 3000);
}*/
void MainWindow::on_actionOpen_File_triggered()
{
    //qDebug() << "Open File Triggered at: " << QTime::currentTime();//checking if being called several times for the dialog window, solved
    //tracking time consumed
    QElapsedTimer timer;
    timer.start();




    QString fileName = QFileDialog::getOpenFileName(
        this,
        tr("Open File"),
        "",
        tr("STL and Text Files (*.stl *.txt)")
        );

    if (fileName.isEmpty()) {
        emit statusUpdateMessage("No file selected.", 0);
        return;
    }

    QFileInfo selectedFile(fileName);
    QDir directory = selectedFile.absoluteDir();

    // 仅筛选出 .stl 和 .txt 文件
    QStringList filters;
    filters << "*.stl" << "*.txt";
    directory.setNameFilters(filters);

    QStringList filteredFiles = directory.entryList(QDir::Files | QDir::NoDotAndDotDot);

    //progress bar, placed under filtered files
    filesLoaded = 0;
    totalFiles = filteredFiles.size();

    if (progressBar) {
        statusBar()->removeWidget(progressBar);
        delete progressBar;
    }

    progressBar = new QProgressBar(this);
    progressBar->setRange(0, totalFiles);
    progressBar->setValue(0);
    progressBar->setTextVisible(true);
    statusBar()->addPermanentWidget(progressBar);


    // 清空旧模型并重建
    delete partList;
    partList = new ModelPartList("Parts List");
    ui->treeView->setModel(partList);

    QModelIndex rootIndex = QModelIndex();
    vtkSmartPointer<vtkRenderer> renderer = vtkSmartPointer<vtkRenderer>::New();
    ui->VTKOpenGLNativeWidget->renderWindow()->AddRenderer(renderer);
    renderer->SetBackground(0.1, 0.2, 0.3);



    for (const QString& file : filteredFiles) {
        QString fullPath = directory.absoluteFilePath(file);
        QList<QVariant> columns = { file, "true" };

        QModelIndex index = partList->appendChild(rootIndex, columns);
        ModelPart* part = static_cast<ModelPart*>(index.internalPointer());

        // ✅ 异步加载 STL，并在主线程渲染
        (void)QtConcurrent::run([this, part, fullPath, renderer]() {
            part->loadSTL(fullPath);

            QMetaObject::invokeMethod(this, [this, part, renderer]() {
                if (part->getActor()) {
                    renderer->AddActor(part->getActor());
                    renderer->ResetCamera();  // ✅ 非常重要：确保摄像机能看到模型
                    ui->VTKOpenGLNativeWidget->renderWindow()->Render();

                    filesLoaded++;
                    progressBar->setValue(filesLoaded);
                    statusBar()->showMessage(QString("Loaded %1 of %2").arg(filesLoaded).arg(totalFiles), 3000);

                    //updating status
                    if (filesLoaded == totalFiles) {
                        statusBar()->showMessage("All files loaded", 5000);
                        QTimer::singleShot(2000, this, [this]() {
                            statusBar()->removeWidget(progressBar);
                            delete progressBar;
                            progressBar = nullptr;
                        });
                    }
                }
            }, Qt::QueuedConnection);
        });
    }

    ui->VTKOpenGLNativeWidget->renderWindow()->Render();
    /*
    QModelIndex rootIndex = QModelIndex();
    for (const QString& file : filteredFiles) {
        QList<QVariant> columns = { file, "true" };
        partList->appendChild(rootIndex, columns);
    }*/
    emit statusUpdateMessage("Loaded directory: " + directory.absolutePath(), 5000);
    qDebug() << "Total load time: " << timer.elapsed() << " ms";
}


void MainWindow::on_actionSave_File_triggered() {

    // Add this line of code so you can see if the action is working
    emit statusUpdateMessage(QString("Save File action triggered"), 0);
}
