#include "mainwindow.h"
#include "./ui_mainwindow.h" //created by UIC of qt from .ui files
#include "ModelPart.h"
#include "ModelPartList.h"
#include <QFileDialog>//for adding dialog
#include <QtConcurrent>//for concurrent process
#include <QProgressBar>//for showing progress of loading stl model using concurrent
#include <QInputDialog>//for right click context menu
#include <QColorDialog>//for right click context menu


#include <QVTKOpenGLNativeWidget.h>
#include <vtkCylinderSource.h>
#include <vtkPolyDataMapper.h>
#include <vtkActor.h>
#include <vtkRenderer.h>
#include <vtkRenderWindow.h>
#include <vtkProperty.h>
#include <vtkRendererCollection.h>

#include <QMessageBox>//forsave color config
#include <QDate>//forsave color config
#include <QFileInfo>//forsave color config



MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);//initialize

    // Create / allocate the Model List
    this->partList = new ModelPartList("Parts List");

    // Link it to the treeview in the GUI
    ui->treeView->setModel(this->partList);

    // Manually create a model tree (quick example for starting point)
    ModelPart* rootItem = this->partList->getRootItem();

    // Add 3 top level items::wait to be modified later for items
    for (int i = 0; i < 3; i++) {
        // Create strings for both data columns
        QString name = QString("Top Level %1").arg(i);
        QString visible("true");  // ✅ 修正：原为 Qstring v i s i b l e

        // Create child item
        ModelPart* childItem = new ModelPart({name, visible});

        // Append to tree top-level
        rootItem->appendChild(childItem);

        // Add 5 sub-items
        for (int j = 0; j < 5; j++) {
            QString name = QString("Item %1, %2").arg(i).arg(j);
            QString visible("true");  // ✅ 同上

            ModelPart* childChildItem = new ModelPart({name, visible});
            childItem->appendChild(childChildItem);
        }
    }


    /**connect(ui->save,&QPushButton::clicked,this,&MainWindow::saveClicked);//connecting signal with slots
    connect(ui->open,&QPushButton::clicked,this,&MainWindow::openClicked);//connecting signal with slots
    */

    /*connect(ui->shrinkFilter,&QCheckBox::stateChanged,this,&MainWindow::shrink_FilterClicked);//connecting signal with slots
    connect(ui->clipFilter,&QCheckBox::stateChanged,this,&MainWindow::clip_FilterClicked);//connecting signal with slots note avoid deprecated*/
    connect(ui->shrinkFilter, &QCheckBox::checkStateChanged, this, &MainWindow::shrink_FilterClicked);
    connect(ui->clipFilter, &QCheckBox::checkStateChanged, this, &MainWindow::clip_FilterClicked);

    connect(this, &MainWindow::statusUpdateMessage,ui->statusbar, &QStatusBar::showMessage);//connecting signals with status bar
    connect(ui->treeView, &QTreeView::clicked,this, &MainWindow::handleTreeClicked);//connecting treeview items

    //connect(ui->actionOpen_File, &QAction::triggered,this, &MainWindow::on_actionOpen_File_triggered);//Openfile action, note:linked directly by ui viaMOC槽函数在此处被重复调用，引掉以避免ui及cpp中的重复调用，窗口现在仅弹出一次，成功
    //connect(ui->actionSave_File, &QAction::triggered, this, &MainWindow::saveColorConfiguration);//save file function moved to on actionSave File triggered
    //connect(ui->actionSave_File, &QAction::triggered,this, &MainWindow::on_actionSave_File_triggered);//Savefile action

    //connecting rgb vertical slider with private slots
    connect(ui->rSlider, &QSlider::valueChanged, this, &MainWindow::updateColorFromSliders);
    connect(ui->gSlider, &QSlider::valueChanged, this, &MainWindow::updateColorFromSliders);
    connect(ui->bSlider, &QSlider::valueChanged, this, &MainWindow::updateColorFromSliders);

    //adding right click
    ui->treeView->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(ui->treeView, &QTreeView::customContextMenuRequested, this, &MainWindow::showContextMenu);

    vtkNew<vtkCylinderSource> cylinder;
    cylinder->SetResolution(16);

    vtkNew<vtkPolyDataMapper> mapper;
    mapper->SetInputConnection(cylinder->GetOutputPort());

    vtkNew<vtkActor> actor;
    actor->SetMapper(mapper);

    mainRenderer = vtkSmartPointer<vtkRenderer>::New();
    mainRenderer->SetBackground(0.1, 0.2, 0.4);
    mainRenderer->AddActor(actor);
    ui->VTKOpenGLNativeWidget->renderWindow()->AddRenderer(mainRenderer);    //note:new version vtk changed the coding
    /** ✅ 关键：使用正确名称的 VTK widgetui->VTKOpenGLNativeWidget->GetRenderWindow()->AddRenderer(renderer);*/



}

MainWindow::~MainWindow()
{
    delete ui;//release memory
}
/**void MainWindow::saveClicked(){
    //qDebug()<<"Button Clicked";
    emit statusUpdateMessage("Saved!", 3000);  //save file::wait to be add to the file list later
}

void MainWindow::openClicked(){
    emit statusUpdateMessage("Opened!", 3000);  //open file::wait to be add to the file list later
    //wait to be added loop for adding all the files
};//open
*/
void MainWindow::shrink_FilterClicked(int state)
{
    if (state == Qt::Checked)
        emit statusUpdateMessage("Shrink Filter: ON", 3000);
    else
        emit statusUpdateMessage("Shrink Filter: OFF", 3000);
}
//checkbox shrink

void MainWindow::clip_FilterClicked(int state)
{
    if (state == Qt::Checked)
        emit statusUpdateMessage("Clip Filter: ON", 3000);
    else
        emit statusUpdateMessage("Clip Filter: OFF", 3000);
}
//checkbox clip
/*
void MainWindow::handleTreeClicked(const QModelIndex &index)
{
    if (!index.isValid()) return;

    // 获取点击的 ModelPart
    ModelPart* part = static_cast<ModelPart*>(index.internalPointer());
    if (!part) return;

    QString name = part->data(0).toString();  // 第0列是名称
    QString visible = part->data(1).toString();  // 第1列是可见性

    // 显示在状态栏
    emit statusUpdateMessage("Selected: " + name + " (Visible: " + visible + ")", 3000);

    // 此处可加入其他操作，例如高亮、渲染等
}*/
/**void MainWindow::handleTreeClicked(const QModelIndex &index)//note:remember set max and min of slider
{
    if (!index.isValid()) return;

    ModelPart* part = static_cast<ModelPart*>(index.internalPointer());
    if (!part) return;

    currentSelectedPart = part;//saving the current selected part

    if (part->getActor()) {//set new model
        double* rgb = part->getActor()->GetProperty()->GetColor();
        ui->rSlider->setValue(static_cast<int>(rgb[0] * 255));
        ui->gSlider->setValue(static_cast<int>(rgb[1] * 255));
        ui->bSlider->setValue(static_cast<int>(rgb[2] * 255));

        //part->getActor()->GetProperty()->SetColor(1.0, 0.0, 0.0); // 红
    }


    emit statusUpdateMessage("Selected: " + part->data(0).toString(), 3000);
    //quoted and changed by upper
    // 重置所有 actor 为默认颜色
    //for (int i = 0; i < partList->rowCount(QModelIndex()); ++i) {
    //    ModelPart* child = static_cast<ModelPart*>(partList->index(i, 0, QModelIndex()).internalPointer());

    //    if (child && child->getActor()) {
    //        child->getActor()->GetProperty()->SetColor(1.0, 1.0, 1.0); // 白
    //    }
    //}

    // 设置当前选中 actor 为高亮颜色
    if (part->getActor()) {
        part->getActor()->GetProperty()->SetColor(1.0, 0.0, 0.0); // 红
    }
//    ui->VTKOpenGLNativeWidget->renderWindow()->Render(); // 更新
}*/
/**void MainWindow::handleTreeClicked(const QModelIndex &index)
{
    if (!index.isValid()) return;

    ModelPart* part = static_cast<ModelPart*>(index.internalPointer());
    if (!part) return;

    currentSelectedPart = part;

    if (part->getActor()) {
        double* rgb = part->getActor()->GetProperty()->GetColor();

        // 👇 自动同步到 slider
        ui->rSlider->setValue(static_cast<int>(rgb[0] * 255));
        ui->gSlider->setValue(static_cast<int>(rgb[1] * 255));
        ui->bSlider->setValue(static_cast<int>(rgb[2] * 255));
    }

    emit statusUpdateMessage("Selected: " + part->data(0).toString(), 3000);
    ui->VTKOpenGLNativeWidget->renderWindow()->Render();
}*/
void MainWindow::handleTreeClicked(const QModelIndex &index)
{
    if (!index.isValid()) return;

    ModelPart* part = static_cast<ModelPart*>(index.internalPointer());
    if (!part || !part->getActor()) return;

    // 设置当前选中模型
    currentSelectedPart = part;

    // 读取模型颜色并更新 slider，不修改 actor 本身的颜色
    double* rgb = part->getActor()->GetProperty()->GetColor();
    ui->rSlider->blockSignals(true);
    ui->gSlider->blockSignals(true);
    ui->bSlider->blockSignals(true);
    ui->rSlider->setValue(static_cast<int>(rgb[0] * 255));
    ui->gSlider->setValue(static_cast<int>(rgb[1] * 255));
    ui->bSlider->setValue(static_cast<int>(rgb[2] * 255));
    ui->rSlider->blockSignals(false);
    ui->gSlider->blockSignals(false);
    ui->bSlider->blockSignals(false);

    emit statusUpdateMessage("Selected: " + part->data(0).toString(), 3000);
    ui->VTKOpenGLNativeWidget->renderWindow()->Render(); // 仅刷新画面
}



// Slot function added to MainWindow.cpp for save and open
/**void MainWindow::on_actionOpen_File_triggered() {

    // Add this line of code so you can see if the action is working
    emit statusUpdateMessage(QString("Open File action triggered"), 0);
}*/
//second version for open stl and txt file
/**void MainWindow::on_actionOpen_File_triggered()
{
    QString fileName = QFileDialog::getOpenFileName(
        this,
        tr("Open File"),
        "",
        tr("STL Files (*.stl);;All Files (*)")
        );

    if (!fileName.isEmpty()) {
        emit statusUpdateMessage("file selected: " + fileName, 0);
    } else {
        emit statusUpdateMessage("no file yet been chosen", 0);
    }
}*/
/**void MainWindow::on_actionOpen_File_triggered()
{
    QString fileName = QFileDialog::getOpenFileName(
        this,
        tr("Open File"),
        "",
        tr("All Files (*)")
        );

    if (fileName.isEmpty()) {
        emit statusUpdateMessage("No file selected.", 0);
        return;
    }

    QFileInfo selectedFile(fileName);
    QDir directory = selectedFile.absoluteDir();
    QStringList fileList = directory.entryList(QDir::Files | QDir::NoDotAndDotDot);

    // 清空旧模型（如需要，可扩展为多模型共存）
    delete partList;
    partList = new ModelPartList("Parts List");
    ui->treeView->setModel(partList);

    QModelIndex rootIndex = QModelIndex();
    for (const QString& file : fileList) {
        QList<QVariant> columns = { file, "true" };
        partList->appendChild(rootIndex, columns);
    }

    emit statusUpdateMessage("Loaded directory: " + directory.absolutePath(), 3000);
}*/

void MainWindow::on_actionOpen_File_triggered()
{
    QElapsedTimer timer;
    timer.start();

    // 选择任一 .stl 或 .txt 文件
    QString fileName = QFileDialog::getOpenFileName(
        this,
        tr("Open File"),
        "",
        tr("STL Files (*.stl);;Text Files (*.txt)"));

    if (fileName.isEmpty()) {
        emit statusUpdateMessage("No file selected.", 0);
        return;
    }

    QFileInfo selectedFile(fileName);
    QDir directory = selectedFile.absoluteDir();

    // 获取所有符合条件的文件
    QStringList filters;
    filters << "*.stl" << "*.txt";
    directory.setNameFilters(filters);
    QStringList filteredFiles = directory.entryList(QDir::Files | QDir::NoDotAndDotDot);

    // 按后缀分类
    QStringList stlFiles, txtFiles;
    for (const QString& file : filteredFiles) {
        if (file.endsWith(".stl", Qt::CaseInsensitive))
            stlFiles << file;
        else if (file.endsWith(".txt", Qt::CaseInsensitive))
            txtFiles << file;
    }

    // 清空旧模型数据
    delete partList;
    partList = new ModelPartList("Parts List");
    ui->treeView->setModel(partList);

    // 初始化渲染器
    mainRenderer->RemoveAllViewProps();  // 清除旧模型
    mainRenderer->SetBackground(0.1, 0.2, 0.3);


    // 初始化进度条
    filesLoaded = 0;
    totalFiles = stlFiles.size();

    if (progressBar) {
        statusBar()->removeWidget(progressBar);
        delete progressBar;
    }

    progressBar = new QProgressBar(this);
    progressBar->setRange(0, totalFiles);
    progressBar->setValue(0);
    statusBar()->addPermanentWidget(progressBar);

    // 添加分类根项
    QModelIndex rootIndex = QModelIndex();
    QModelIndex stlRoot = partList->appendChild(rootIndex, { "1.stl", "" });
    QModelIndex txtRoot = partList->appendChild(rootIndex, { "2.txt", "" });

    // 加载 STL 文件并渲染
    for (const QString& file : stlFiles) {
        QString fullPath = directory.absoluteFilePath(file);
        QModelIndex index = partList->appendChild(stlRoot, { file, "true" });
        ModelPart* part = static_cast<ModelPart*>(index.internalPointer());

        (void)QtConcurrent::run([this, part, fullPath]() {
            part->loadSTL(fullPath);

            QMetaObject::invokeMethod(this, [this, part]() {
                if (part->getActor()) {
                    mainRenderer->AddActor(part->getActor());
                    mainRenderer->ResetCamera();
                    ui->VTKOpenGLNativeWidget->renderWindow()->Render();

                    filesLoaded++;
                    progressBar->setValue(filesLoaded);

                    if (filesLoaded == totalFiles) {
                        statusBar()->showMessage("All files loaded", 5000);
                        QTimer::singleShot(2000, this, [this]() {
                            statusBar()->removeWidget(progressBar);
                            delete progressBar;
                            progressBar = nullptr;
                        });
                    }
                }
            }, Qt::QueuedConnection);
        });

    }

    // 加载 txt 文件到 TreeView（不参与渲染）
    for (const QString& file : txtFiles) {
        partList->appendChild(txtRoot, {  file, "" });
    }

    emit statusUpdateMessage("Loaded directory: " + directory.absolutePath(), 5000);
    qDebug() << "Total load time: " << timer.elapsed() << " ms";
}

/*
void MainWindow::on_actionSave_File_triggered() {

    // Add this line of code so you can see if the action is working
    emit statusUpdateMessage(QString("Save File action triggered"), 0);

}*/
void MainWindow::on_actionSave_File_triggered()
{
    if (partList->rowCount(QModelIndex()) == 0) {
        QMessageBox::warning(this, "Error", "No parts loaded.");
        return;
    }

    QModelIndex topGroup = partList->index(0, 0, QModelIndex());
    QModelIndex firstModel = partList->index(0, 0, topGroup);
    ModelPart* firstPart = findFirstValidPart(partList->getRootItem());

    if (!firstPart || firstPart->filePath.isEmpty()) {
        QMessageBox::warning(this, "Error", "No valid STL model found.");
        return;
    }


    QFileInfo fileInfo(firstPart->filePath);
    QString folderName = fileInfo.dir().dirName();
    QString defaultFileName = folderName + "_rawRGB.csv";
    QString defaultPath = fileInfo.dir().absoluteFilePath(defaultFileName);

    QString savePath = QFileDialog::getSaveFileName(
        this,
        "Save Raw RGB Color Data",
        defaultPath,
        "CSV Files (*.csv);;Text Files (*.txt)");

    if (savePath.isEmpty()) {
        statusBar()->showMessage("Save canceled.", 3000);
        return;
    }

    QFile file(savePath);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Error", "Cannot write to file.");
        return;
    }

    QTextStream out(&file);
    out << "PartName,R,G,B\n";

    std::function<void(const QModelIndex&)> recurse;
    recurse = [&](const QModelIndex& parent) {
        int rowCount = partList->rowCount(parent);
        for (int i = 0; i < rowCount; ++i) {
            QModelIndex index = partList->index(i, 0, parent);
            ModelPart* part = static_cast<ModelPart*>(index.internalPointer());
            if (part && part->getActor()) {
                double* rgb = part->getActor()->GetProperty()->GetColor();
                QString name = QFileInfo(part->filePath).fileName();
                out << name << "," << rgb[0] << "," << rgb[1] << "," << rgb[2] << "\n";
            }
            recurse(index);
        }
    };

    recurse(QModelIndex());
    file.close();

    statusBar()->showMessage("Raw RGB color data saved to " + savePath, 5000);
}
/**
void MainWindow::on_actionSave_File_triggered()
{
    QString fileName = QFileDialog::getSaveFileName(this, tr("Save Configuration"), "", tr("Text Files (*.txt);;All Files (*)"));

    if (fileName.isEmpty()) {
        emit statusUpdateMessage("Save canceled.", 0);
        return;
    }

    QFile file(fileName);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QMessageBox::warning(this, tr("Unable to open file"), file.errorString());
        return;
    }

    QTextStream out(&file);

    // Traverse through the part list and write each part's color
    QModelIndex rootIndex = QModelIndex();
    for (int i = 0; i < partList->rowCount(rootIndex); ++i) {
        ModelPart* part = static_cast<ModelPart*>(partList->index(i, 0, rootIndex).internalPointer());
        if (part && part->getActor()) {
            double* color = part->getActor()->GetProperty()->GetColor();
            out << part->data(0).toString() << " "
                << color[0] << " "
                << color[1] << " "
                << color[2] << "\n";
        }
    }

    file.close();
    emit statusUpdateMessage("Configuration saved to " + fileName, 3000);
}*/



void MainWindow::updateColorFromSliders()
{
    if (!currentSelectedPart || !currentSelectedPart->getActor()) return;

    double r = ui->rSlider->value() / 255.0;
    double g = ui->gSlider->value() / 255.0;
    double b = ui->bSlider->value() / 255.0;

    currentSelectedPart->getActor()->GetProperty()->SetColor(r, g, b);
    ui->VTKOpenGLNativeWidget->renderWindow()->Render();
    emit statusUpdateMessage(QString("Color updated: R=%1, G=%2, B=%3")
                                 .arg(ui->rSlider->value())
                                 .arg(ui->gSlider->value())
                                 .arg(ui->bSlider->value()), 1000);
}

ModelPart* MainWindow::findFirstValidPart(ModelPart* parent) {
    if (!parent) return nullptr;
    if (!parent->filePath.isEmpty()) return parent;

    for (int i = 0; i < parent->childCount(); ++i) {
        ModelPart* child = parent->child(i);
        ModelPart* found = findFirstValidPart(child);
        if (found) return found;
    }
    return nullptr;
}

void MainWindow::on_actionLoad_triggered()
{
    QString filePath = QFileDialog::getOpenFileName(this, "Load Color Configuration", "", "CSV Files (*.csv)");

    if (filePath.isEmpty()) {
        statusBar()->showMessage("Load canceled.", 3000);
        return;
    }

    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Error", "Cannot open file.");
        return;
    }

    QTextStream in(&file);
    QString header = in.readLine(); // Skip header line

    // 读取每一行并应用颜色
    while (!in.atEnd()) {
        QString line = in.readLine().trimmed();
        if (line.isEmpty()) continue;

        QStringList parts = line.split(",");
        if (parts.size() != 4) continue;

        QString fileName = parts[0];
        double r = parts[1].toDouble();
        double g = parts[2].toDouble();
        double b = parts[3].toDouble();

        std::function<void(ModelPart*)> applyColor;
        applyColor = [&](ModelPart* part) {
            if (!part) return;

            if (QFileInfo(part->filePath).fileName() == fileName) {
                if (part->getActor()) {
                    part->getActor()->GetProperty()->SetColor(r, g, b);
                    if (part == currentSelectedPart) {
                        ui->rSlider->blockSignals(true);
                        ui->gSlider->blockSignals(true);
                        ui->bSlider->blockSignals(true);
                        ui->rSlider->setValue(static_cast<int>(r * 255));
                        ui->gSlider->setValue(static_cast<int>(g * 255));
                        ui->bSlider->setValue(static_cast<int>(b * 255));
                        ui->rSlider->blockSignals(false);
                        ui->gSlider->blockSignals(false);
                        ui->bSlider->blockSignals(false);
                    }
                }
            }

            for (int i = 0; i < part->childCount(); ++i) {
                applyColor(part->child(i));
            }
        };

        applyColor(partList->getRootItem());
    }

    file.close();
    ui->VTKOpenGLNativeWidget->renderWindow()->Render();
    statusBar()->showMessage("Color configuration loaded from " + filePath, 5000);
}

void MainWindow::showContextMenu(const QPoint& pos)
{
    QModelIndex index = ui->treeView->indexAt(pos);
    if (!index.isValid()) return;

    ModelPart* part = static_cast<ModelPart*>(index.internalPointer());
    if (!part) return;

    QMenu contextMenu(this);

    QAction* toggleVisibility = contextMenu.addAction("Toggle Visibility");
    QAction* renamePart = contextMenu.addAction("Rename Model");
    QAction* changeColor = contextMenu.addAction("Change Color");
    contextMenu.addSeparator();

    QMenu* filterMenu = contextMenu.addMenu("Apply Filter");
    QAction* shrinkAction = filterMenu->addAction("Shrink");
    QAction* clipAction = filterMenu->addAction("Clip");
    contextMenu.addSeparator();

    QAction* addModel = contextMenu.addAction("Add Child Model");
    QAction* removeModel = contextMenu.addAction("Delete This Model");

    QAction* selectedAction = contextMenu.exec(ui->treeView->viewport()->mapToGlobal(pos));
    if (!selectedAction) return;

    if (selectedAction == toggleVisibility) {
        bool visible = part->visible();
        part->setVisible(!visible);
        if (part->getActor()) {
            part->getActor()->SetVisibility(!visible);
            ui->VTKOpenGLNativeWidget->renderWindow()->Render();
        }
    } else if (selectedAction == renamePart) {
        bool ok;
        QString newName = QInputDialog::getText(this, "Rename Model", "New name:", QLineEdit::Normal, part->data(0).toString(), &ok);
        if (ok && !newName.trimmed().isEmpty()) {
            part->set(0, newName);
            partList->layoutChanged();
        }
    } else if (selectedAction == changeColor) {
        QColor color = QColorDialog::getColor(Qt::white, this, "Select Color");
        if (color.isValid() && part->getActor()) {
            part->getActor()->GetProperty()->SetColor(color.redF(), color.greenF(), color.blueF());
            ui->VTKOpenGLNativeWidget->renderWindow()->Render();
        }
    } else if (selectedAction == addModel) {
        QString filePath = QFileDialog::getOpenFileName(this, "Add STL Model", "", "STL Files (*.stl)");
        if (filePath.isEmpty()) return;

        QFileInfo info(filePath);
        QString name = info.fileName();

        // 检查在父类下是否已有同名子模型
        /**for (int i = 0; i < part->childCount(); ++i) {
            if (part->child(i)->data(0).toString() == name) {
                QMessageBox::warning(this, "Duplicate", "This file is already loaded under this part.");
                return;
            }
        }*/
        //checking through whole dic
        if (isSTLAlreadyLoaded(filePath)) {
            QMessageBox::warning(this, "Duplicate", "This STL file is already loaded in the model tree.");
            return;
        }


        emit statusUpdateMessage("Loading model: " + name, 2000);

        ModelPart* newPart = new ModelPart({ name, "true" }, part);
        newPart->loadSTL(filePath);
        newPart->filePath = filePath;

        // 继承颜色与可见性
        if (part->getActor() && newPart->getActor()) {
            double* rgb = part->getActor()->GetProperty()->GetColor();
            newPart->getActor()->GetProperty()->SetColor(rgb[0], rgb[1], rgb[2]);
            newPart->setVisible(part->visible());
            newPart->getActor()->SetVisibility(part->visible() ? 1 : 0);
        }

        part->appendChild(newPart);

        if (newPart->getActor()) {
            mainRenderer->AddActor(newPart->getActor());
            mainRenderer->ResetCamera();
            ui->VTKOpenGLNativeWidget->renderWindow()->Render();
        }

        partList->layoutChanged();
        emit statusUpdateMessage("Model loaded: " + name, 3000);
    } else if (selectedAction == removeModel) {
        if (QMessageBox::question(this, "Confirm Delete", "Delete this model and all submodels?") == QMessageBox::Yes) {

            std::function<void(ModelPart*)> removeActorsRecursively;
            removeActorsRecursively = [&](ModelPart* part) {
                if (part->getActor()) {
                    mainRenderer->RemoveActor(part->getActor());
                }
                for (int i = 0; i < part->childCount(); ++i) {
                    removeActorsRecursively(part->child(i));
                }
            };
            removeActorsRecursively(part);

            if (!partList->removePart(index)) {
                QMessageBox::warning(this, "Error", "Failed to delete model.");
            } else {
                if (currentSelectedPart == part) currentSelectedPart = nullptr;
                ui->VTKOpenGLNativeWidget->renderWindow()->Render();
            }
        }
    } else if (selectedAction == shrinkAction) {
        part->applyShrinkFilter();
        ui->VTKOpenGLNativeWidget->renderWindow()->Render();
        emit statusUpdateMessage("Shrink filter applied to: " + part->data(0).toString(), 2000);
    } else if (selectedAction == clipAction) {
        part->applyClipFilter();
        ui->VTKOpenGLNativeWidget->renderWindow()->Render();
        emit statusUpdateMessage("Clip filter applied to: " + part->data(0).toString(), 2000);
    }
}


//checking if exist
/**bool MainWindow::isSTLAlreadyLoaded(const QString& filePath) {
    QFileInfo newFileInfo(filePath);
    QString newFileName = newFileInfo.fileName();

    std::function<bool(ModelPart*)> check;
    check = [&](ModelPart* part) -> bool {
        if (!part) return false;

        QFileInfo existingInfo(part->filePath);
        if (!part->filePath.isEmpty() && existingInfo.fileName() == newFileName) {
            return true;
        }

        for (int i = 0; i < part->childCount(); ++i) {
            if (check(part->child(i))) return true;
        }
        return false;
    };

    return check(partList->getRootItem());
}*/
bool MainWindow::isSTLAlreadyLoaded(const QString& filePath) {
    QFileInfo newFileInfo(filePath);
    QString newFileName = newFileInfo.fileName(); // 仅检查文件名，不含路径

    std::function<bool(ModelPart*)> check;
    check = [&](ModelPart* part) -> bool {
        if (!part) return false;

        QFileInfo existingInfo(part->filePath);
        if (!part->filePath.isEmpty() &&
            existingInfo.fileName().compare(newFileName, Qt::CaseInsensitive) == 0) {
            return true;
        }

        for (int i = 0; i < part->childCount(); ++i) {
            if (check(part->child(i))) return true;
        }
        return false;
    };

    return check(partList->getRootItem());
}
