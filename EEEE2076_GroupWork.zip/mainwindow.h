#ifndef MAINWINDOW_H//avoiding redefination
#define MAINWINDOW_H

#include <QMainWindow>
#include "ModelPartList.h"
#include <QProgressBar>
#include <vtkRenderer.h>

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT//for signal and slots

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

// Slot function declaration added to MainWindow
public slots://question: what's difference between public slots and public, just slots and variables?
    //allow file filter of txt and stl
    void on_actionOpen_File_triggered();
    void on_actionSave_File_triggered();
    void on_actionLoad_triggered();


private:
    Ui::MainWindow *ui;
    //void saveClicked();//save
    //void openClicked();//open
    void saveColorConfiguration();//saving config for all model

    void handleTreeClicked(const QModelIndex &index);//Treeview slot for modifying items
    ModelPart* findFirstValidPart(ModelPart* parent);
    void shrink_FilterClicked(int state);//filter_shrink
    void clip_FilterClicked(int state);//filter_clip

    void showContextMenu(const QPoint& pos);//right click

    bool isSTLAlreadyLoaded(const QString& filePath);//checking stl for loading child


    //progress bar
    QProgressBar* progressBar = nullptr;
    int filesLoaded = 0;
    int totalFiles = 0;

    ModelPartList* partList;

    ModelPart* currentSelectedPart = nullptr;//for rgb adjustment in mainwindow

    vtkSmartPointer<vtkRenderer> mainRenderer;//for deleting renderer



private slots:
    void updateColorFromSliders();


signals:
    void statusUpdateMessage(const QString &message, int timeout);//signal for status bar
};
#endif // MAINWINDOW_H
